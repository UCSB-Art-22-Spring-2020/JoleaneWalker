var total = 150; //total # of particles
var plist=[]; //empty array

function setup() {
  createCanvas(400, 400);
  
  for(let i=0; i<total; i++){
   plist.push(new particle()); //add=push new particles to the plist 
  }
  
}

function draw() {
  background(223, 240, 247);
  for(let i=0; i<plist.length; i++){
      plist[i].display();
  }
  
}
class particle{
  //variables and constructors
  // x and y postitions
  constructor(){
    this.x=random(0,width);
    this.y=random(0,height);
  }
  display(){
    stroke(51, 41, 186);
    strokeWeight(5);
    point(this.x,this.y);
    
    this.x+=random(-5,5);
    this.y+=random(-5,5);
  
    if(this.x<0||this.x >width||this.y<0||this.y>height){
      this.x=random(0, width);
      this.y=random(0,height);
    }
  }
  
}